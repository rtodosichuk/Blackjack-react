export default {
  deck: [],
  dealerCards: [],
  dealerFirstCard: 0,
  dealerFirstCardAlt: 0,
  dealerTotal: 0,
  dealerTotalAlt: 0,
  playerCards: [],
  playerTotal: 0,
  playerTotalAlt: 0,
  bet: 0,
  totalChips: 100,
  gameMessage: '',
  gameInProgress: false
};